/**
 * Firebase API Wrapper for Frontend
 * 
 * This provides a Firebase-based API that mirrors my old REST calls.
 */

const firebaseApi = {
  // Authentication ---------------------
  async login(email, password) {
    try {
      const userCredential = await window.firebaseAuth.signInWithEmailAndPassword(email, password);
      const user = userCredential.user;
      
      const userDoc = await window.firebaseDb.collection('users').doc(user.uid).get();
      const userData = userDoc.exists ? userDoc.data() : {};
      
      const token = await user.getIdToken();
      localStorage.setItem('token', token);
      localStorage.setItem('firebaseUser', JSON.stringify({ uid: user.uid, ...userData }));
      
      return {
        token,
        user: {
          uid: user.uid,
          email: user.email,
          ...userData
        }
      };
    } catch (error) {
      throw new Error(this.getAuthErrorMessage(error.code));
    }
  },

  async signup(email, password, extraData = {}) {
    try {
      const userCredential = await window.firebaseAuth.createUserWithEmailAndPassword(email, password);
      const user = userCredential.user;
      
      const userData = {
        email: user.email,
        createdAt: new Date().toISOString(),
        ...extraData
      };

      await window.firebaseDb.collection('users').doc(user.uid).set(userData);
      
      const token = await user.getIdToken();
      localStorage.setItem('token', token);
      localStorage.setItem('firebaseUser', JSON.stringify({ uid: user.uid, ...userData }));
      
      return {
        token,
        user: {
          uid: user.uid,
          email: user.email,
          ...userData
        }
      };
    } catch (error) {
      throw new Error(this.getAuthErrorMessage(error.code));
    }
  },

  async logout() {
      await window.firebaseAuth.signOut();
      localStorage.removeItem('token');
      localStorage.removeItem('firebaseUser');
  },

  getCurrentUser() {
    const stored = localStorage.getItem('firebaseUser');
    if (!stored) return null;
    try { return JSON.parse(stored); } catch { return null; }
  },

  // Firestore Helpers ---------------------
  async saveData(collection, docId, data) {
    await window.firebaseDb.collection(collection).doc(docId).set(data, { merge: true });
      return { success: true };
  },

  async getData(collection, docId) {
    const doc = await window.firebaseDb.collection(collection).doc(docId).get();
    if (!doc.exists) return null;
    return doc.data();
  },

  async list(collection, queryBuilder = null) {
    let ref = window.firebaseDb.collection(collection);
    if (typeof queryBuilder === 'function') ref = queryBuilder(ref);

    const snapshot = await ref.get();
    const items = [];
    snapshot.forEach(doc => items.push({ id: doc.id, ...doc.data() }));
    return items;
  },

  async update(collection, docId, data) {
    await window.firebaseDb.collection(collection).doc(docId).update(data);
    return { success: true };
  },

  getAuthErrorMessage(code) {
    const m = {
      'auth/user-not-found': 'No user found.',
      'auth/wrong-password': 'Incorrect password.',
      'auth/email-already-in-use': 'Email already used.',
      'auth/weak-password': 'Password too weak.',
      'auth/invalid-email': 'Invalid email.',
    };
    return m[code] || 'Authentication failed.';
  }
};

// Expose globally
window.firebaseApi = firebaseApi;

/**
 * ClearTrack Auth API - Focused auth + profile helper API for login flow
 * 
 * Provides simplified authentication helpers for the ClearTrack login system.
 */
(function() {
  'use strict';

  // Verify Firebase instances are available
  if (!window.firebaseAuth) {
    console.error('cleartrackAuthApi: window.firebaseAuth is not available. Ensure firebase-init.js is loaded first.');
    return;
  }

  if (!window.firebaseDb) {
    console.error('cleartrackAuthApi: window.firebaseDb is not available. Ensure firebase-init.js is loaded first.');
    return;
  }

  /**
   * Login with email and password
   * @param {string} email - User email
   * @param {string} password - User password
   * @returns {Promise<Object>} User credential object
   */
  async function loginWithEmailPassword(email, password) {
    try {
      const userCredential = await window.firebaseAuth.signInWithEmailAndPassword(email, password);
      return userCredential.user;
    } catch (error) {
      console.error('cleartrackAuthApi.loginWithEmailPassword error:', error);
      throw error;
    }
  }

  /**
   * Get user profile from Firestore
   * @param {string} uid - User ID
   * @returns {Promise<Object>} User profile data
   * @throws {Error} If user document does not exist
   */
  async function getUserProfile(uid) {
    try {
      const userDoc = await window.firebaseDb.collection('users').doc(uid).get();
      
      if (!userDoc.exists) {
        throw new Error(`User profile not found for uid: ${uid}`);
      }

      return userDoc.data();
    } catch (error) {
      console.error('cleartrackAuthApi.getUserProfile error:', error);
      throw error;
    }
  }

  /**
   * Redirect user based on their role
   * @param {string} role - User role ('practitioner', 'admin', or other)
   */
  function redirectByRole(role) {
    if (role === 'practitioner') {
      window.location.href = '/practitioner-dashboard.html';
    } else if (role === 'admin') {
      window.location.href = '/admin-dashboard.html';
    } else {
      window.location.href = '/user-dashboard.html';
    }
  }

  /**
   * Observe auth state on login page and auto-redirect if already logged in
   * Optional helper for login pages
   */
  function observeAuthStateOnLoginPage() {
    window.firebaseAuth.onAuthStateChanged(async (user) => {
      if (user) {
        try {
          console.log('cleartrackAuthApi: User already logged in, loading profile...');
          const profile = await getUserProfile(user.uid);
          
          if (profile && profile.role) {
            console.log('cleartrackAuthApi: Redirecting by role:', profile.role);
            redirectByRole(profile.role);
          } else {
            console.warn('cleartrackAuthApi: User profile found but no role field, defaulting to user dashboard');
            redirectByRole('user');
          }
    } catch (error) {
          console.error('cleartrackAuthApi: Error loading profile for auto-redirect:', error);
          // Don't redirect if we can't load the profile
        }
      }
    });
  }

  /**
   * Helper function to redirect based on role (reusable)
   * @param {string} role - User role
   */
  function redirectBasedOnRole(role) {
    if (role === 'practitioner') {
      window.location.href = '/practitioner-dashboard.html';
    } else {
      window.location.href = '/user-dashboard.html';
    }
  }

  /**
   * Login with email and password, then redirect based on role
   * This is the main login function for the login page
   * @param {string} email - User email
   * @param {string} password - User password
   * @returns {Promise<void>}
   */
  async function loginWithEmailPasswordAndRedirect(email, password) {
    const auth = window.firebaseAuth;
    const db = window.firebaseDb;

    const userCredential = await auth.signInWithEmailAndPassword(email, password);
    const user = userCredential.user;

    // Fetch role from Firestore: users/{uid}
    const docRef = db.collection('users').doc(user.uid);
    const snap = await docRef.get();

    let role = 'user';
    if (snap.exists) {
      const data = snap.data();
      if (data && data.role) {
        role = data.role;
      }
    }

    // Route based on role
    redirectBasedOnRole(role);
  }

  /**
   * Watch auth state and redirect if already logged in
   * Used on login page to auto-redirect authenticated users
   */
  function watchAuthStateAndRedirectIfLoggedIn() {
    const auth = window.firebaseAuth;
    auth.onAuthStateChanged(async (user) => {
      if (!user) return; // stay on login page

      try {
        // Read role from Firestore
        const db = window.firebaseDb;
        const docRef = db.collection('users').doc(user.uid);
        const snap = await docRef.get();

        let role = 'user';
        if (snap.exists) {
          const data = snap.data();
          if (data && data.role) {
            role = data.role;
          }
        }

        // Redirect based on role
        redirectBasedOnRole(role);
      } catch (error) {
        console.error('Error loading user profile for auto-redirect:', error);
        // Don't redirect if we can't load the profile
      }
    });
  }

  // Expose the API globally (for backward compatibility)
  window.cleartrackAuthApi = {
    loginWithEmailPassword,
    getUserProfile,
    redirectByRole,
    observeAuthStateOnLoginPage,
    loginWithEmailPasswordAndRedirect,
    watchAuthStateAndRedirectIfLoggedIn
  };

  console.log('cleartrackAuthApi initialized successfully');

  // ES Module exports (for use with import statements)
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
      loginWithEmailPassword: loginWithEmailPasswordAndRedirect,
      watchAuthStateAndRedirectIfLoggedIn
    };
  }
})();

// ES Module exports (for browsers with ES modules)
// These functions handle login and redirect based on Firestore role
export async function loginWithEmailPassword(email, password) {
  if (!window.firebaseAuth || !window.firebaseDb) {
    throw new Error('Firebase not initialized. Ensure firebase-init.js is loaded first.');
  }

  const auth = window.firebaseAuth;
  const db = window.firebaseDb;

  const userCredential = await auth.signInWithEmailAndPassword(email, password);
  const user = userCredential.user;

  // Fetch role from Firestore: users/{uid}
  const docRef = db.collection('users').doc(user.uid);
  const snap = await docRef.get();

  let role = 'user';
  if (snap.exists) {
    const data = snap.data();
    if (data && data.role) {
      role = data.role;
    }
  }

  // Route based on role
  if (role === 'practitioner') {
    window.location.href = '/practitioner-dashboard.html';
  } else {
    window.location.href = '/user-dashboard.html';
  }
}

export function watchAuthStateAndRedirectIfLoggedIn() {
  if (!window.firebaseAuth || !window.firebaseDb) {
    console.error('Firebase not initialized. Ensure firebase-init.js is loaded first.');
    return;
  }

  const auth = window.firebaseAuth;
  auth.onAuthStateChanged(async (user) => {
    if (!user) return; // stay on login page

    try {
      // Read role from Firestore
      const db = window.firebaseDb;
      const docRef = db.collection('users').doc(user.uid);
      const snap = await docRef.get();

      let role = 'user';
      if (snap.exists) {
        const data = snap.data();
        if (data && data.role) {
          role = data.role;
        }
      }

      // Redirect based on role
      if (role === 'practitioner') {
        window.location.href = '/practitioner-dashboard.html';
      } else if (role === 'admin') {
        window.location.href = '/admin-dashboard.html';
      } else {
        window.location.href = '/user-dashboard.html';
      }
    } catch (error) {
      console.error('Error loading user profile for auto-redirect:', error);
      // Don't redirect if we can't load the profile
    }
  });
}
