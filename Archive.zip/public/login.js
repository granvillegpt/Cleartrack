/**
 * Login and Registration Handler for ClearTrack
 * 
 * Handles both login and registration form submissions and routes users 
 * to the correct dashboard based on their Firestore role field.
 */

// Global error message element reference
let errorMessageElement = null;

// Helper function to hide error (accessible globally)
function hideError() {
  if (errorMessageElement) {
    errorMessageElement.classList.remove('show');
    errorMessageElement.textContent = '';
  }
}

// Global functions for form switching - explicitly attach to window
window.switchToSignIn = function() {
  const signInTab = document.getElementById('signInTab');
  const registerTab = document.getElementById('registerTab');
  const loginForm = document.getElementById('loginForm');
  const registerForm = document.getElementById('registerForm');
  const formTitle = document.getElementById('formTitle');
  const formDescription = document.getElementById('formDescription');
  
  if (signInTab) signInTab.classList.add('active');
  if (registerTab) registerTab.classList.remove('active');
  if (loginForm) loginForm.classList.add('active');
  if (registerForm) registerForm.classList.remove('active');
  if (formTitle) formTitle.textContent = 'Sign In';
  if (formDescription) formDescription.textContent = 'Enter your credentials to access your dashboard';
  hideError();
};

window.switchToRegister = function() {
  const signInTab = document.getElementById('signInTab');
  const registerTab = document.getElementById('registerTab');
  const loginForm = document.getElementById('loginForm');
  const registerForm = document.getElementById('registerForm');
  const formTitle = document.getElementById('formTitle');
  const formDescription = document.getElementById('formDescription');
  
  if (signInTab) signInTab.classList.remove('active');
  if (registerTab) registerTab.classList.add('active');
  if (loginForm) loginForm.classList.remove('active');
  if (registerForm) registerForm.classList.add('active');
  if (formTitle) formTitle.textContent = 'Create Account';
  if (formDescription) formDescription.textContent = 'Sign up to get started with ClearTrack';
  hideError();
};

document.addEventListener('DOMContentLoaded', function() {
  const loginForm = document.getElementById('loginForm');
  const registerForm = document.getElementById('registerForm');
  const emailInput = document.getElementById('email');
  const passwordInput = document.getElementById('password');
  const submitBtn = document.getElementById('submitBtn');
  const registerBtn = document.getElementById('registerBtn');
  errorMessageElement = document.getElementById('errorMessage');
  
  // Add event listeners for tab buttons as backup (in addition to onclick handlers)
  const signInTab = document.getElementById('signInTab');
  const registerTab = document.getElementById('registerTab');
  
  if (signInTab) {
    signInTab.addEventListener('click', function(e) {
      e.preventDefault();
      window.switchToSignIn();
    });
  }
  
  if (registerTab) {
    registerTab.addEventListener('click', function(e) {
      e.preventDefault();
      window.switchToRegister();
    });
  }

  // Validate all required elements exist
  if (!errorMessageElement) {
    console.error('[login.js] Error message element not found');
    return;
  }

  if (!loginForm) {
    console.error('[login.js] Login form not found');
    return;
  }

  if (!registerForm) {
    console.error('[login.js] Register form not found');
    return;
  }

  if (!registerBtn) {
    console.error('[login.js] Register button not found');
    return;
  }

  console.log('[login.js] All form elements found, initializing handlers...');

  // Helper function to show error
  function showError(message) {
    if (errorMessageElement) {
      errorMessageElement.textContent = message;
      errorMessageElement.classList.add('show');
    }
  }

  // Helper function to set loading state for login
  function setLoginLoading(isLoading) {
    submitBtn.disabled = isLoading;
    submitBtn.textContent = isLoading ? 'Signing in...' : 'Sign In';
  }

  // Helper function to set loading state for registration
  function setRegisterLoading(isLoading) {
    registerBtn.disabled = isLoading;
    registerBtn.textContent = isLoading ? 'Creating account...' : 'Create Account';
  }

  // Helper function to route user based on role
  async function routeUser(role, userId) {
    if (role === 'practitioner') {
      window.location.href = '/practitioner-dashboard.html';
    } else {
      // For clients, check if they have a practitioner
      // If not, redirect to onboarding
      if (window.firebaseDb && userId) {
        try {
          const userDoc = await window.firebaseDb.collection('users').doc(userId).get();
          if (userDoc.exists) {
            const userData = userDoc.data();
            const practitionerId = userData.practitionerId || userData.connectedPractitioner || null;
            if (!practitionerId) {
              // No practitioner - redirect to onboarding
              window.location.href = '/client-onboarding.html';
              return;
            }
          }
        } catch (error) {
          console.error('Error checking practitioner:', error);
        }
      }
      // Has practitioner or error - go to dashboard
      window.location.href = '/user-dashboard.html';
    }
  }

  // Handle login form submission
  loginForm.addEventListener('submit', async function(e) {
    e.preventDefault();
    hideError();

    const email = emailInput.value.trim();
    const password = passwordInput.value;

    if (!email || !password) {
      showError('Please enter both email and password.');
      return;
    }

    // Check if Firebase API is available
    if (!window.firebaseApi) {
      showError('Firebase is not initialized. Please refresh the page.');
      console.error('firebaseApi not available');
      return;
    }

    setLoginLoading(true);

    try {
      // Call Firebase login
      const result = await window.firebaseApi.login(email, password);

      if (!result || !result.user) {
        throw new Error('Invalid response from login');
      }

      // Get user role from Firestore data
      const role = result.user.role || result.user.userRole || 'user';

      console.log('Login successful. User role:', role);

      // Route based on role
      await routeUser(role, result.user.uid);

    } catch (error) {
      console.error('Login error:', error);
      
      // Show user-friendly error message
      const errorMsg = error.message || 'An error occurred during login. Please try again.';
      showError(errorMsg);
      setLoginLoading(false);
    }
  });

  // Handle registration form submission
  registerForm.addEventListener('submit', async function(e) {
    e.preventDefault();
    e.stopPropagation();
    
    console.log('[login.js] Register form submitted');
    hideError();

    const firstNameEl = document.getElementById('registerFirstName');
    const lastNameEl = document.getElementById('registerLastName');
    const emailEl = document.getElementById('registerEmail');
    const passwordEl = document.getElementById('registerPassword');
    const roleEl = document.querySelector('input[name="role"]:checked');

    if (!firstNameEl || !lastNameEl || !emailEl || !passwordEl || !roleEl) {
      console.error('[login.js] Registration form fields not found');
      showError('Form fields not found. Please refresh the page.');
      return;
    }

    const firstName = firstNameEl.value.trim();
    const lastName = lastNameEl.value.trim();
    const email = emailEl.value.trim();
    const password = passwordEl.value;
    const role = roleEl.value || 'client'; // Default to client

    console.log('[login.js] Registration data:', { firstName, lastName, email, role: role, passwordLength: password.length });

    // Validation
    if (!firstName || !lastName || !email || !password) {
      showError('Please fill in all fields.');
      return;
    }

    if (password.length < 6) {
      showError('Password must be at least 6 characters long.');
      return;
    }

    // Check if Firebase API is available
    if (!window.firebaseApi) {
      showError('Firebase is not initialized. Please refresh the page.');
      console.error('[login.js] firebaseApi not available');
      return;
    }

    if (!window.firebaseApi.signup) {
      showError('Registration is not available. Please refresh the page.');
      console.error('[login.js] firebaseApi.signup method not found');
      return;
    }

    setRegisterLoading(true);

    try {
      // Prepare user data for Firestore
      const extraData = {
        firstName: firstName,
        lastName: lastName,
        name: `${firstName} ${lastName}`,
        role: role,
        createdAt: new Date().toISOString()
      };

      console.log('[login.js] Calling firebaseApi.signup with:', { email, extraData });

      // Call Firebase signup
      const result = await window.firebaseApi.signup(email, password, extraData);

      console.log('[login.js] Signup result:', result);

      if (!result || !result.user) {
        throw new Error('Invalid response from registration');
      }

      console.log('[login.js] Registration successful. User role:', role);

      // Route based on role
      await routeUser(role, result.user.uid);

    } catch (error) {
      console.error('[login.js] Registration error:', error);
      console.error('[login.js] Error details:', error.message, error.code);
      
      // Show user-friendly error message
      const errorMsg = error.message || 'An error occurred during registration. Please try again.';
      showError(errorMsg);
      setRegisterLoading(false);
    }
  });

  console.log('[login.js] Registration form handler attached');
});
