// public/firebase-config.js

const firebaseConfig = {
  apiKey: "AIzaSyAacjIUCyGRHvY2BnPawkLiWp1IYjJKPjk",
  authDomain: "cleartrack-1f6c6.firebaseapp.com",
  projectId: "cleartrack-1f6c6",
  storageBucket: "cleartrack-1f6c6.appspot.com",
  messagingSenderId: "634138353416",
  appId: "1:634138353416:web:4b799295c2d17450f896bd"
};

// Expose config so firebase-init.js and firebase-api.js can use it
window.firebaseConfig = firebaseConfig;
